# Question Paper Decryptor (Android)

An offline Android starter project for processing authorized question-paper archives produced by the supplied Windows ClientTools format.

## Features
- Android document picker for an encrypted ZIP.
- Exam-day password entry.
- Local decryption; no server upload.
- Extracts `.sbtet` entries and verifies the `%PDF` signature.
- Saves the recovered PDFs inside a ZIP that can be opened on Android or a computer.

## Compatibility
- Minimum Android: 8.0 (API 26)
- Compile/target SDK: 35
- Uses the observed ClientTools decryption parameters: 32-byte salt prefix, PBKDF2-HMAC-SHA1 (50,000 iterations), AES-256 ECB, PKCS padding.

## Build the APK
1. Install Android Studio (current stable) on a computer.
2. Open this project folder.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.
6. Transfer it to your Android phone and install it. Android may ask you to allow installation from that file manager.

## Important
- This project is a source/build starter, not a compiled or device-tested APK.
- It requires the correct authorized exam-day password and compatible input format.
- Test with a non-sensitive sample archive first. If the source format changes, update the decryption routine accordingly.
- Keep decrypted examination papers secure and follow your institution's handling rules.


## Build APK in GitHub Actions (no local Windows PC needed)
1. Create a free GitHub account and a new repository.
2. Upload the contents of this project folder to the repository (keep the `.github/workflows/build-apk.yml` file).
3. Open the repository's **Actions** tab and run **Build Android APK** (or push to `main`).
4. When the workflow finishes, open its run and download the `QuestionPaperDecryptor-debug-apk` artifact.
5. Extract the artifact ZIP and install `app-debug.apk` on your Android phone.

The cloud workflow compiles the project; it does not bypass the required exam-day password or institutional authorization. This APK is still a debug build and has not been tested on every Android device.
