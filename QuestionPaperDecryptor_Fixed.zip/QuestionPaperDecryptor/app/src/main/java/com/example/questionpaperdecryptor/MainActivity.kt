package com.example.questionpaperdecryptor

import androidx.activity.ComponentActivity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.security.spec.KeySpec
import java.util.zip.ZipInputStream
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

class MainActivity : ComponentActivity() {
    private var selectedZip: Uri? = null
    private lateinit var status: TextView
    private lateinit var password: EditText
    private lateinit var chooseButton: Button
    private lateinit var runButton: Button

    private val pickZip = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            selectedZip = uri
            status.text = "Selected: ${uri.lastPathSegment ?: "ZIP file"}"
        }
    }

    private val createOutput = registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            val inputUri = pendingOutput
            if (inputUri != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(pendingBytes) }
                    status.text = "Finished. Decrypted PDFs saved in the ZIP file."
                } catch (e: Exception) {
                    status.text = "Could not save output: ${e.message}"
                }
            }
        }
    }

    private var pendingOutput = "Question_Papers_Decrypted.zip"
    private var pendingBytes: ByteArray = byteArrayOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 32)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val heading = TextView(this).apply {
            text = "Question Paper Decryptor"
            textSize = 24f
            setTextColor(0xFF17365D.toInt())
        }
        password = EditText(this).apply {
            hint = "Enter exam-day password"
            inputType = 129
            textSize = 17f
        }
        chooseButton = Button(this).apply {
            text = "Select encrypted ZIP"
            setOnClickListener { pickZip.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) }
        }
        runButton = Button(this).apply {
            text = "Decrypt and prepare PDFs"
            setOnClickListener { decryptSelected() }
        }
        status = TextView(this).apply {
            text = "Select the encrypted question-paper ZIP and enter its authorized password."
            textSize = 15f
            setPadding(0, 24, 0, 0)
        }
        layout.addView(heading)
        layout.addView(password)
        layout.addView(chooseButton)
        layout.addView(runButton)
        layout.addView(status)
        setContentView(layout)
    }

    private fun decryptSelected() {
        val uri = selectedZip
        val pass = password.text.toString()
        if (uri == null) { status.text = "Please select a ZIP file."; return }
        if (pass.isBlank()) { status.text = "Please enter the exam-day password."; return }

        runButton.isEnabled = false
        status.text = "Processing locally on this phone..."
        Thread {
            try {
                val encrypted = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val outerZipBytes = decryptFile(encrypted, pass)
                val pdfs = linkedMapOf<String, ByteArray>()
                ZipInputStream(ByteArrayInputStream(outerZipBytes)).use { zis ->
                    while (true) {
                        val entry = zis.nextEntry ?: break
                        if (!entry.isDirectory) {
                            val bytes = zis.readBytes()
                            if (entry.name.endsWith(".sbtet", ignoreCase = true)) {
                                val pdf = decryptFile(bytes, pass)
                                if (pdf.size >= 4 && pdf.copyOfRange(0, 4).toString(Charsets.US_ASCII) == "%PDF") {
                                    val name = entry.name.removeSuffix(".sbtet").removeSuffix(".SBTET")
                                    pdfs[name.substringAfterLast('/')] = pdf
                                }
                            } else if (entry.name.endsWith(".pdf", ignoreCase = true)) {
                                pdfs[entry.name.substringAfterLast('/')] = bytes
                            }
                        }
                        zis.closeEntry()
                    }
                }
                if (pdfs.isEmpty()) throw IllegalStateException("No valid PDF files found. Check the password and input file.")
                pendingBytes = zipPdfs(pdfs)
                pendingOutput = "Question_Papers_Decrypted.zip"
                runOnUiThread { createOutput.launch(pendingOutput) }
            } catch (e: Exception) {
                runOnUiThread { status.text = "Decryption failed: ${e.message ?: "Invalid file or password"}" }
            } finally {
                runOnUiThread { runButton.isEnabled = true }
            }
        }.start()
    }

    // Matches the supplied Windows ClientTools FileDecrypt routine:
    // 32-byte salt prefix, PBKDF2-HMAC-SHA1, 50,000 iterations,
    // 256-bit AES key, ECB mode, PKCS7 padding.
    private fun decryptFile(input: ByteArray, password: String): ByteArray {
        require(input.size > 32) { "Encrypted file is too short." }
        val salt = input.copyOfRange(0, 32)
        val cipherText = input.copyOfRange(32, input.size)
        val spec: KeySpec = PBEKeySpec(password.toCharArray(), salt, 50000, 256)
        val keyBytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1")
            .generateSecret(spec).encoded
        val cipher = Cipher.getInstance("AES/ECB/PKCS5Padding")
        cipher.init(Cipher.DECRYPT_MODE, SecretKeySpec(keyBytes, "AES"))
        return cipher.doFinal(cipherText)
    }

    private fun zipPdfs(pdfs: Map<String, ByteArray>): ByteArray {
        val output = ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(output).use { zos ->
            for ((name, bytes) in pdfs) {
                zos.putNextEntry(java.util.zip.ZipEntry(name))
                zos.write(bytes)
                zos.closeEntry()
            }
        }
        return output.toByteArray()
    }
}
